Este es un repositorio para el proyecto "Techcore" una aplicacion creada en android estudio utilizando el lenguaje de kotlin 
