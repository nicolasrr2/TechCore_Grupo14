# TecnoCore - Aplicación de E-Commerce para Android

Proyecto final para la Evaluación Parcial 2 (DSY1105). TecnoCore es una aplicación móvil Android nativa que simula una tienda de productos tecnológicos, implementando una arquitectura moderna y cumpliendo con una serie de requisitos técnicos específicos.

## Autores

- Katya (¡Puedes poner tu nombre completo aquí!)

## Características Implementadas

- **Arquitectura MVVM:** Separación clara de la lógica (ViewModel), los datos (Repository) y la interfaz (Activity/XML).
- **Persistencia Local con Room:** Toda la información (usuarios, productos, carrito) se guarda en una base de datos local SQLite gestionada por Room, usando coroutines y Flow para un rendimiento asíncrono y reactivo.
- **Autenticación de Usuarios:** Flujo completo de registro e inicio de sesión.
- **Catálogo de Productos:** La pantalla principal muestra una lista de productos obtenidos de la base de datos.
- **Carrito de Compras:** Funcionalidad para añadir productos a un carrito persistente.
- **Uso de Recursos Nativos:**
  - **Cámara:** El usuario puede tomar una foto de perfil durante el registro.
  - **Ubicación:** Se puede obtener la última ubicación conocida del dispositivo desde la pantalla principal.
- **Animaciones y Feedback Visual:** Transiciones suaves entre pantallas y notificaciones al interactuar con la aplicación.
- **Gestión de Permisos:** Solicitud de permisos en tiempo de ejecución para la cámara y la ubicación.

## Requerimientos Técnicos

- **Lenguaje:** Kotlin
- **UI:** Android XML (sin Jetpack Compose)
- **Versión Mínima de Android:** API 24 (Nougat)
- **Librerías Principales:** ViewModel, LiveData, Room, Coroutines, ViewBinding, Material Components, Google Play Services Location.

## Cómo Ejecutar el Proyecto

1. Clona este repositorio.
2. Abre el proyecto con Android Studio (versión Koala o superior recomendada).
3. Espera a que Gradle sincronice todas las dependencias.
4. Ejecuta la aplicación en un emulador o en un dispositivo físico.

---
*Este proyecto fue guiado y construido con la ayuda de Gemini en Android Studio.*