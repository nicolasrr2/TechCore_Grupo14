package com.tecnocore.app.ui.main

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.tecnocore.app.data.entities.Producto
import com.tecnocore.app.databinding.ItemProductBinding
import com.tecnocore.app.utils.AnimUtils

class ProductoAdapter(
    private val onProductoClicked: (Producto) -> Unit,
    private val onAddToCartClicked: (Producto) -> Unit
) : ListAdapter<Producto, ProductoAdapter.ProductoViewHolder>(ProductoDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductoViewHolder {
        val binding = ItemProductBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProductoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductoViewHolder, position: Int) {
        val producto = getItem(position)
        holder.bind(producto)
    }

    inner class ProductoViewHolder(private val binding: ItemProductBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(producto: Producto) {
            binding.tvTitle.text = producto.title
            binding.tvPrice.text = String.format("$%.2f", producto.price)
            binding.tvDesc.text = producto.description

            binding.root.setOnClickListener {
                onProductoClicked(producto)
            }

            binding.btnAdd.setOnClickListener {
                // Delega la acción al ViewModel a través del lambda
                onAddToCartClicked(producto)
                // Feedback visual (IL 2.2.2)
                AnimUtils.pulse(it)
            }
        }
    }
}

class ProductoDiffCallback : DiffUtil.ItemCallback<Producto>() {
    override fun areItemsTheSame(oldItem: Producto, newItem: Producto): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Producto, newItem: Producto): Boolean {
        return oldItem == newItem
    }
}
