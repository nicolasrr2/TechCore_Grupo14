package com.tecnocore.app.ui.main

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.tecnocore.app.R
import com.tecnocore.app.data.entities.Producto
import com.tecnocore.app.databinding.ItemProductBinding

class ProductoAdapter(
    private val onProductoClicked: (Producto) -> Unit,
    private val onAddToCartClicked: (Producto, ImageView) -> Unit
) : ListAdapter<Producto, ProductoAdapter.ProductoViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductoViewHolder {
        val binding = ItemProductBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProductoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductoViewHolder, position: Int) {
        val producto = getItem(position)
        holder.bind(producto)
    }

    inner class ProductoViewHolder(private val binding: ItemProductBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(producto: Producto) {
            binding.tvTitle.text = producto.title
            binding.tvPrice.text = String.format("$%.2f", producto.price)
            binding.tvDesc.text = producto.description

            binding.ivProductImage.load(producto.imageRes ?: R.drawable.ic_placeholder) {
                placeholder(R.drawable.ic_placeholder)
                error(R.drawable.ic_placeholder)
            }

            binding.root.setOnClickListener {
                onProductoClicked(producto)
            }
            binding.btnAdd.setOnClickListener {
                onAddToCartClicked(producto, binding.ivProductImage)
            }
        }
    }

    companion object {
        private val DiffCallback = object : DiffUtil.ItemCallback<Producto>() {
            override fun areItemsTheSame(oldItem: Producto, newItem: Producto): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: Producto, newItem: Producto): Boolean {
                return oldItem == newItem
            }
        }
    }
}
