package com.tecnocore.app.domain

object Validate {
    fun isEmailValid(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    fun isPasswordValid(password: String): Boolean {
        // mínimo 6 caracteres (ajusta según rubrica)
        return password.length >= 6
    }

    fun isNameValid(name: String): Boolean {
        return name.trim().length >= 2
    }
}
