package com.tecnocore.app.ui.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.tecnocore.app.data.repository.CarritoRepository
import com.tecnocore.app.data.repository.ProductoRepository

class MainViewModelFactory(
    private val productoRepository: ProductoRepository,
    private val carritoRepository: CarritoRepository
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MainViewModel(productoRepository, carritoRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
