package com.tecnocore.app.ui.main

// This file is obsolete and can be deleted.
// MainViewModel is now an AndroidViewModel and is instantiated using by viewModels().
