package com.tecnocore.app.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.tecnocore.app.data.entities.CartItem
import kotlinx.coroutines.flow.Flow

@Dao
interface CartDao {

    @Query("SELECT * FROM cart_items")
    fun getAllFlow(): Flow<List<CartItem>>

    @Query("SELECT * FROM cart_items WHERE productId = :productId LIMIT 1")
    suspend fun getItemByProductId(productId: Long): CartItem?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(item: CartItem): Long

    @Update
    suspend fun update(item: CartItem)

    @Delete
    suspend fun delete(item: CartItem)

    @Query("DELETE FROM cart_items")
    suspend fun clearAll()

    @Transaction
    suspend fun upsert(item: CartItem) {
        val existingItem = getItemByProductId(item.productId)
        if (existingItem == null) {
            // El producto es nuevo en el carrito, lo insertamos con cantidad 1
            insert(item.copy(quantity = 1))
        } else {
            // El producto ya existe, actualizamos su cantidad
            val updatedItem = existingItem.copy(quantity = existingItem.quantity + 1)
            update(updatedItem)
        }
    }
}
