package com.tecnocore.app.data.dao

import androidx.room.*
import com.tecnocore.app.data.entities.CartItem
import kotlinx.coroutines.flow.Flow

@Dao
interface CartDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: CartItem): Long

    @Update
    suspend fun update(item: CartItem)

    @Delete
    suspend fun delete(item: CartItem)

    @Query("SELECT * FROM cart_items")
    fun getAllFlow(): Flow<List<CartItem>>

    @Query("DELETE FROM cart_items")
    suspend fun clearAll()
}
