package com.tecnocore.app.data.repository

import com.tecnocore.app.data.entities.Producto
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

/**
 * Repositorio para gestionar los productos. 
 * En esta versión, los productos son estáticos, pero se prepara la estructura para un futuro acceso a BD.
 */
class ProductoRepository() {

    // Por ahora, devolvemos un Flow vacío ya que los datos son estáticos en el ViewModel
    fun todosLosProductos(): Flow<List<Producto>> {
        return flowOf(emptyList())
    }

    // Aquí podrían ir métodos como getProductoById, etc. en el futuro
}
