package com.tecnocore.app.ui.carrito

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.tecnocore.app.data.database.AppDatabase
import com.tecnocore.app.data.repository.CartRepository
import com.tecnocore.app.databinding.ActivityCarritoBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ActivityCarrito : AppCompatActivity() {

    private lateinit var binding: ActivityCarritoBinding
    private lateinit var adapter: CartAdapter
    private val cartRepo by lazy { CartRepository(AppDatabase.getInstance(this).cartDao()) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCarritoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = CartAdapter(mutableListOf(), onRemove = { item ->
            lifecycleScope.launch {
                cartRepo.remove(item)
            }
        }, onQuantityChanged = { item ->
            lifecycleScope.launch {
                cartRepo.update(item)
            }
        })

        binding.recyclerCart.layoutManager = LinearLayoutManager(this)
        binding.recyclerCart.adapter = adapter

        lifecycleScope.launch {
            cartRepo.getCartFlow().collectLatest { items ->
                adapter.updateItems(items.toMutableList())
                val total = items.sumOf { it.price * it.quantity }
                binding.tvTotal.text = String.format("Total: $%.2f", total)
            }
        }

        binding.btnCheckout.setOnClickListener {
            // Simular compra: limpiar carrito y mostrar mensaje
            lifecycleScope.launch {
                cartRepo.clearCart()
                Toast.makeText(this@ActivityCarrito, "Compra simulada realizada", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}
