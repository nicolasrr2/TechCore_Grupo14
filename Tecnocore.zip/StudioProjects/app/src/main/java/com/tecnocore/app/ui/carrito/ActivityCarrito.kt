package com.tecnocore.app.ui.carrito

import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.tecnocore.app.databinding.ActivityCarritoBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ActivityCarrito : AppCompatActivity() {

    private lateinit var binding: ActivityCarritoBinding
    private lateinit var adapter: CartAdapter
    private val viewModel: CartViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCarritoBinding.inflate(layoutInflater)
        setContentView(binding.root)


        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        setupRecyclerView()
        observeViewModel()
        setupEventListeners()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupRecyclerView() {
        adapter = CartAdapter(
            onRemoveClicked = { item ->
                viewModel.removeItem(item)
            },
            onQuantityChanged = { item, newQuantity ->
                viewModel.updateItemQuantity(item, newQuantity)
            }
        )
        binding.recyclerCart.layoutManager = LinearLayoutManager(this)
        binding.recyclerCart.adapter = adapter
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.cartItems.collectLatest { items ->
                adapter.submitList(items)
                val total = items.sumOf { it.price * it.quantity }
                binding.tvTotal.text = String.format("Total: $%.2f", total)
            }
        }
    }

    private fun setupEventListeners() {
        binding.btnCheckout.setOnClickListener {
            viewModel.checkout()
            Toast.makeText(this, "Compra simulada realizada", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
