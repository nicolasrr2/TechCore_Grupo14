package com.tecnocore.app.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "products")
data class Producto(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String,
    val price: Double,
    val stock: Int,
    val rating: Float,
    val imageRes: Int? = null,

    val imageUrl: String? = null
)
