package com.tecnocore.app.data.entities

data class Producto(
    val id: Long,
    val title: String,
    val description: String,
    val price: Double,
    val imageUrl: String? = null
)
