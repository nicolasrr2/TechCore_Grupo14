package com.tecnocore.app.ui.registro

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.tecnocore.app.data.UsuarioViewModel
import com.tecnocore.app.data.Validate

class RegistroViewModel(application: Application) : AndroidViewModel(application) {

    private val usuarioViewModel = UsuarioViewModel(application)

    private val _registroState = MutableLiveData<RegistroState>()
    val registroState: LiveData<RegistroState> = _registroState

    private val _nombreError = MutableLiveData<String?>()
    val nombreError: LiveData<String?> = _nombreError

    private val _emailError = MutableLiveData<String?>()
    val emailError: LiveData<String?> = _emailError

    private val _passwordError = MutableLiveData<String?>()
    val passwordError: LiveData<String?> = _passwordError

    fun registrarUsuario(nombre: String, email: String, pass: String) {
        val isNombreValid = validateNombre(nombre)
        val isEmailValid = validateEmail(email)
        val isPasswordValid = validatePassword(pass)

        if (!isNombreValid || !isEmailValid || !isPasswordValid) {
            _registroState.value = RegistroState.Error("Por favor, corrige los errores.")
            return
        }

        _registroState.value = RegistroState.Loading
        // Aquí simplemente delegamos la lógica de registro al ViewModel central
        usuarioViewModel.registrarUsuario(nombre, email, pass)
        _registroState.value = RegistroState.Success("¡Registro exitoso!")
    }

    fun validateNombre(nombre: String): Boolean {
        return if (!Validate.isNameValid(nombre)) {
            _nombreError.value = "El nombre no puede estar vacío."
            false
        } else {
            _nombreError.value = null
            true
        }
    }

    fun validateEmail(email: String): Boolean {
        return if (!Validate.isEmailValid(email)) {
            _emailError.value = "El formato del email no es válido."
            false
        } else {
            _emailError.value = null
            true
        }
    }

    fun validatePassword(password: String): Boolean {
        return if (!Validate.isPasswordValid(password)) {
            _passwordError.value = "La contraseña debe tener al menos 6 caracteres."
            false
        } else {
            _passwordError.value = null
            true
        }
    }
}

sealed class RegistroState {
    object Loading : RegistroState()
    data class Success(val message: String) : RegistroState()
    data class Error(val message: String) : RegistroState()
}
