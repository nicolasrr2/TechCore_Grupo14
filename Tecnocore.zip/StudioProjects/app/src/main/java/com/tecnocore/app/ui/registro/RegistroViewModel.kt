package com.tecnocore.app.ui.registro

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.tecnocore.app.data.Validate
import com.tecnocore.app.data.database.AppDatabase
import com.tecnocore.app.data.entities.Usuario
import com.tecnocore.app.data.repository.UsuarioRepository
import kotlinx.coroutines.launch

class RegistroViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: UsuarioRepository

    private val _registroState = MutableLiveData<RegistroState>()
    val registroState: LiveData<RegistroState> = _registroState

    private val _nombreError = MutableLiveData<String?>()
    val nombreError: LiveData<String?> = _nombreError

    private val _emailError = MutableLiveData<String?>()
    val emailError: LiveData<String?> = _emailError

    private val _passwordError = MutableLiveData<String?>()
    val passwordError: LiveData<String?> = _passwordError

    private val _confirmPasswordError = MutableLiveData<String?>()
    val confirmPasswordError: LiveData<String?> = _confirmPasswordError

    private val _regionError = MutableLiveData<String?>()
    val regionError: LiveData<String?> = _regionError

    init {
        val usuarioDao = AppDatabase.getInstance(application).usuarioDao()
        repository = UsuarioRepository(usuarioDao)
    }

    fun registrarUsuario(nombre: String, email: String, pass: String, confirmPass: String, region: String) {
        val isNombreValid = validateNombre(nombre, true)
        val isEmailValid = validateEmail(email, true)
        val isPasswordValid = validatePassword(pass, true)
        val isConfirmPasswordValid = validateConfirmPassword(pass, confirmPass, true)
        val isRegionValid = validateRegion(region, true)

        if (!isNombreValid || !isEmailValid || !isPasswordValid || !isConfirmPasswordValid || !isRegionValid) {
            _registroState.value = RegistroState.Error("Por favor, corrige los errores.")
            return
        }

        _registroState.value = RegistroState.Loading
        viewModelScope.launch {
            val existe = repository.findUsuarioByEmail(email)
            if (existe != null) {
                _registroState.postValue(RegistroState.Error("El email ya está registrado"))
                return@launch
            }

            // Aquí se añadiría la región al objeto Usuario si el modelo de datos lo permitiera.
            val usuario = Usuario(nombre = nombre, email = email, password = pass)
            val id = repository.registrarUsuario(usuario)

            if (id > 0) {
                _registroState.postValue(RegistroState.Success("¡Registro exitoso!"))
            } else {
                _registroState.postValue(RegistroState.Error("Error desconocido al registrar"))
            }
        }
    }

    fun validateNombre(nombre: String, showError: Boolean = false): Boolean {
        val isValid = Validate.isNameValid(nombre)
        if (!isValid && showError) {
            _nombreError.value = "El nombre no puede estar vacío."
        } else {
            _nombreError.value = null
        }
        return isValid
    }

    fun validateEmail(email: String, showError: Boolean = false): Boolean {
        val isValid = Validate.isEmailValid(email)
        if (!isValid && showError) {
            _emailError.value = "El formato del email no es válido."
        } else {
            _emailError.value = null
        }
        return isValid
    }

    fun validatePassword(password: String, showError: Boolean = false): Boolean {
        val isValid = Validate.isPasswordValid(password)
        if (!isValid && showError) {
            _passwordError.value = "La contraseña debe tener al menos 6 caracteres."
        } else {
            _passwordError.value = null
        }
        return isValid
    }

    fun validateConfirmPassword(password: String, confirm: String, showError: Boolean = false): Boolean {
        val isValid = password == confirm
        if (!isValid && showError) {
            _confirmPasswordError.value = "Las contraseñas no coinciden."
        } else {
            _confirmPasswordError.value = null
        }
        return isValid
    }

    fun validateRegion(region: String, showError: Boolean = false): Boolean {
        val isValid = region.isNotEmpty()
        if (!isValid && showError) {
            _regionError.value = "Debes seleccionar una región."
        } else {
            _regionError.value = null
        }
        return isValid
    }
}

sealed class RegistroState {
    object Loading : RegistroState()
    data class Success(val message: String) : RegistroState()
    data class Error(val message: String) : RegistroState()
}
