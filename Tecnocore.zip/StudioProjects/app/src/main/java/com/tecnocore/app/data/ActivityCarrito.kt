package com.tecnocore.app.data

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.tecnocore.app.R

class ActivityCarrito : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_carrito)
    }
}
