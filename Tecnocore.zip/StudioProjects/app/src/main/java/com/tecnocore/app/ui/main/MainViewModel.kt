package com.tecnocore.app.ui.main

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tecnocore.app.R
import com.tecnocore.app.data.database.AppDatabase
import com.tecnocore.app.data.entities.CartItem
import com.tecnocore.app.data.entities.Producto
import com.tecnocore.app.data.repository.CartRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {


    val productos = listOf(
        Producto(1, "Heladera Samsung", "Capacidad 300L, No Frost, con freezer inferior y tecnología Inverter.", 499.99, 15, 4.5f, imageRes = R.drawable.producto_1),
        Producto(2, "Lavadora Industrial", "Carga frontal de 20kg, ideal para lavanderías comerciales, alta eficiencia energética.", 699.99, 8, 4.8f, imageRes = R.drawable.producto_2),
        Producto(3, "Smart TV 55\"", "Resolución 4K UHD, HDR, Google TV integrado y control por voz.", 899.99, 25, 4.7f, imageRes = R.drawable.producto_3),
        Producto(4, "Microondas X200", "Potencia de 700W con función de grill. Ideal para calentar y dorar tus comidas.", 129.99, 30, 4.2f, imageRes = R.drawable.producto_4)
    )

    private val cartRepo: CartRepository

    init {
        val cartDao = AppDatabase.getInstance(application).cartDao()
        cartRepo = CartRepository(cartDao)
    }

    val cartFlow = cartRepo.getCartFlow().stateIn(viewModelScope, SharingStarted.Lazily, emptyList<CartItem>())

    fun addProductToCart(producto: Producto) {
        viewModelScope.launch {
            val item = CartItem(
                productId = producto.id,
                title = producto.title,
                price = producto.price,
                quantity = 1,
                imageRes = producto.imageRes
            )
            cartRepo.addToCart(item)
        }
    }
}
