package com.tecnocore.app.ui.main

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tecnocore.app.data.entities.Producto
import com.tecnocore.app.data.entities.CartItem
import com.tecnocore.app.data.database.AppDatabase
import com.tecnocore.app.data.repository.CartRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    // Productos estáticos (ejemplo)
    val productos = listOf(
        Producto(1,"Smartphone X1","Procesador rápido, cámara 48MP",399.99,""),
        Producto(2,"Auriculares Pro","Cancelación de ruido",79.99,""),
        Producto(3,"Smartwatch Z","Monitoreo de salud",129.99,"")
    )

    private val cartRepo = CartRepository(AppDatabase.getInstance(application).cartDao())

    val cartFlow = cartRepo.getCartFlow().stateIn(viewModelScope, SharingStarted.Lazily, emptyList<CartItem>())

    fun addProductToCart(producto: Producto) {
        viewModelScope.launch {
            val item = CartItem(productId = producto.id, title = producto.title, price = producto.price, quantity = 1, imageUrl = producto.imageUrl)
            cartRepo.addToCart(item)
        }
    }
}
