package com.tecnocore.app.ui.login

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.tecnocore.app.data.UsuarioViewModel
import com.tecnocore.app.databinding.ActivityInicioSesionBinding
import com.tecnocore.app.ui.main.ActivityPrincipal
import com.tecnocore.app.ui.registro.ActivityRegistro

class ActivityInicioSesion : AppCompatActivity() {

    private lateinit var binding: ActivityInicioSesionBinding
    private val usuarioViewModel: UsuarioViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInicioSesionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener {
            val email = binding.etEmail.text.toString()
            val pass = binding.etPassword.text.toString()
            binding.progressBar.visibility = View.VISIBLE
            usuarioViewModel.loginUsuario(email, pass) { success, msg ->
                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    if (success) {
                        startActivity(Intent(this, ActivityPrincipal::class.java))
                        finish()
                    } else {
                        binding.tilEmail.error = if (msg?.contains("Usuario") == true || msg?.contains("Email") == true) msg else null
                        binding.tilPassword.error = if (msg?.contains("Contraseña") == true) msg else null
                        Toast.makeText(this, msg ?: "Error de inicio de sesión", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        binding.tvGoRegister.setOnClickListener {
            startActivity(Intent(this, ActivityRegistro::class.java))
        }
    }
}
