package com.tecnocore.app.utils

import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.Animation
import android.view.animation.ScaleAnimation

object AnimUtils {
    fun pulse(view: View, duration: Long = 300) {
        val anim = ScaleAnimation(
            1f, 1.05f,
            1f, 1.05f,
            Animation.RELATIVE_TO_SELF, 0.5f,
            Animation.RELATIVE_TO_SELF, 0.5f
        )
        anim.duration = duration
        anim.interpolator = AccelerateDecelerateInterpolator()
        anim.repeatCount = 1
        anim.repeatMode = Animation.REVERSE
        view.startAnimation(anim)
    }
}
