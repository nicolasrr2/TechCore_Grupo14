package com.tecnocore.app.data

import android.graphics.Color
import android.graphics.PorterDuff
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import coil.load
import com.tecnocore.app.R
import com.tecnocore.app.data.entities.Producto
import com.tecnocore.app.databinding.ActivityDetalleBinding
import com.tecnocore.app.ui.main.MainViewModel

class ActivityDetalle : AppCompatActivity() {

    private lateinit var binding: ActivityDetalleBinding
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetalleBinding.inflate(layoutInflater)
        setContentView(binding.root)


        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)


        binding.toolbar.navigationIcon?.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP)

        val productId = intent.getLongExtra("PRODUCT_ID", -1)
        val producto = viewModel.productos.find { it.id == productId }

        if (producto != null) {
            displayProductDetails(producto)
        } else {
            Toast.makeText(this, "Producto no encontrado", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun displayProductDetails(producto: Producto) {

        supportActionBar?.title = producto.title

        binding.ivDetailImage.load(producto.imageRes ?: R.drawable.ic_placeholder) {
            placeholder(R.drawable.ic_placeholder)
            error(R.drawable.ic_placeholder)
        }


        binding.tvDetailTitle.text = producto.title
        binding.tvDetailPrice.text = String.format("$%.2f", producto.price)
        binding.tvDetailDesc.text = producto.description
        binding.tvDetailStock.text = String.format("Stock: %d disponibles", producto.stock)
        binding.rbDetailRating.rating = producto.rating

        binding.fabAddToCart.setOnClickListener {
            viewModel.addProductToCart(producto)
            Toast.makeText(this, "'${producto.title}' añadido al carrito", Toast.LENGTH_SHORT).show()
        }
    }
}
