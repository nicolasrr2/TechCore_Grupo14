package com.tecnocore.app.data

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.tecnocore.app.databinding.ActivityDetalleBinding
import com.tecnocore.app.data.database.AppDatabase
import com.tecnocore.app.data.entities.CartItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ActivityDetalle : AppCompatActivity() {

    private lateinit var binding: ActivityDetalleBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetalleBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val title = intent.getStringExtra("product_title") ?: "Producto"
        val price = intent.getDoubleExtra("product_price", 0.0)
        val desc = intent.getStringExtra("product_description") ?: ""

        binding.tvTitle.text = title
        binding.tvDesc.text = desc
        binding.tvPrice.text = String.format("$%.2f", price)

        binding.btnAddToCart.setOnClickListener {
            // Insert en BD
            val db = AppDatabase.getInstance(this)
            val item = CartItem(productId = intent.getLongExtra("product_id", -1), title = title, price = price, quantity = 1)
            CoroutineScope(Dispatchers.IO).launch {
                db.cartDao().insert(item)
            }
            finish()
        }
    }
}
