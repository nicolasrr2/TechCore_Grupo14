package com.tecnocore.app.ui.login

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.tecnocore.app.data.UsuarioViewModel
import com.tecnocore.app.data.Validate
import com.tecnocore.app.data.entities.Usuario

class LoginViewModel(application: Application) : AndroidViewModel(application) {

    private val usuarioViewModel = UsuarioViewModel(application)

    private val _loginState = MutableLiveData<LoginState>()
    val loginState: LiveData<LoginState> = _loginState

    private val _emailError = MutableLiveData<String?>()
    val emailError: LiveData<String?> = _emailError

    private val _passwordError = MutableLiveData<String?>()
    val passwordError: LiveData<String?> = _passwordError

    fun iniciarSesion(email: String, pass: String) {
        val isEmailValid = validateEmail(email)
        val isPasswordValid = validatePassword(pass)

        if (!isEmailValid || !isPasswordValid) {
            _loginState.value = LoginState.Error("Por favor, corrige los errores.")
            return
        }

        _loginState.value = LoginState.Loading
        usuarioViewModel.loginUsuario(email, pass) { success, msg ->
            if (success) {
                // Simulamos la obtención del usuario para la UI
                // En una app real, el callback podría devolver el usuario
                _loginState.postValue(LoginState.Success(Usuario(nombre = "Usuario", email = email, password = "")))
            } else {
                _loginState.postValue(LoginState.Error(msg ?: "Credenciales incorrectas."))
            }
        }
    }

    fun validateEmail(email: String): Boolean {
        return if (!Validate.isEmailValid(email)) {
            _emailError.value = "El formato del email no es válido."
            false
        } else {
            _emailError.value = null
            true
        }
    }

    fun validatePassword(password: String): Boolean {
        return if (!Validate.isPasswordValid(password)) {
            _passwordError.value = "La contraseña es demasiado corta."
            false
        } else {
            _passwordError.value = null
            true
        }
    }
}

sealed class LoginState {
    object Loading : LoginState()
    data class Success(val usuario: Usuario) : LoginState()
    data class Error(val message: String) : LoginState()
}
