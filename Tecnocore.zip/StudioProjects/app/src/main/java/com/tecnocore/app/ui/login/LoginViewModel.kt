package com.tecnocore.app.ui.login

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.tecnocore.app.data.database.AppDatabase
import com.tecnocore.app.data.repository.UsuarioRepository
import kotlinx.coroutines.launch

class LoginViewModel(application: Application) : AndroidViewModel(application) {

    private val usuarioRepository: UsuarioRepository

    private val _loginState = MutableLiveData<LoginState>()
    val loginState: LiveData<LoginState> = _loginState

    init {
        val usuarioDao = AppDatabase.getInstance(application).usuarioDao()
        usuarioRepository = UsuarioRepository(usuarioDao)
    }

    fun iniciarSesion(email: String, pass: String) {
        // Validaciones básicas
        if (email.isBlank() || pass.isBlank()) {
            _loginState.value = LoginState.Error("Por favor, ingrese correo y contraseña")
            return
        }

        _loginState.value = LoginState.Loading

        viewModelScope.launch {
            val usuario = usuarioRepository.findUsuarioByEmail(email)

            if (usuario == null) {
                _loginState.postValue(LoginState.Error("El usuario no existe"))
            } else if (usuario.password != pass) {
                _loginState.postValue(LoginState.Error("Contraseña incorrecta"))
            } else {
                _loginState.postValue(LoginState.Success)
            }
        }
    }
}

sealed class LoginState {
    object Loading : LoginState()
    object Success : LoginState()
    data class Error(val message: String) : LoginState()
}
