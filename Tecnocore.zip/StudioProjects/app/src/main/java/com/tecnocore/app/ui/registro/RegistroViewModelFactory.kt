package com.tecnocore.app.ui.registro

// This file is obsolete and can be deleted.
// RegistroViewModel is now an AndroidViewModel and is instantiated using by viewModels().
