package com.tecnocore.app.ui.login

// This file is obsolete and can be deleted.
// LoginViewModel is now an AndroidViewModel and is instantiated using by viewModels().
