package com.tecnocore.app.ui.detalle

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.tecnocore.app.data.entities.Producto
import com.tecnocore.app.ui.main.MainViewModel

class DetalleViewModel(application: Application) : AndroidViewModel(application) {

    private val _producto = MutableLiveData<Producto?>()
    val producto: LiveData<Producto?> = _producto


    fun cargarProducto(productoId: Long) {
        val mainViewModel = MainViewModel(getApplication())
        val productoEncontrado = mainViewModel.productos.find { it.id == productoId }
        _producto.value = productoEncontrado
    }
}
