package com.tecnocore.app.data

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.tecnocore.app.R

class ActivityAgregar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_agregar)
    }
}
