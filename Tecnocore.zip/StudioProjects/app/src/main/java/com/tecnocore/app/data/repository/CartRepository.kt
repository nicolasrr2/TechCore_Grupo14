package com.tecnocore.app.data.repository

import com.tecnocore.app.data.dao.CartDao
import com.tecnocore.app.data.entities.CartItem
import kotlinx.coroutines.flow.Flow

class CartRepository(private val cartDao: CartDao) {

    fun getCartFlow(): Flow<List<CartItem>> {
        return cartDao.getAllFlow()
    }

    suspend fun addToCart(item: CartItem) {
        // Llama al nuevo método upsert para manejar la lógica de forma segura
        cartDao.upsert(item)
    }

    suspend fun removeItem(item: CartItem) {
        cartDao.delete(item)
    }

    suspend fun updateItemQuantity(item: CartItem, newQuantity: Int) {
        if (newQuantity <= 0) {
            cartDao.delete(item)
        } else {
            cartDao.update(item.copy(quantity = newQuantity))
        }
    }

    suspend fun clearCart() {
        cartDao.clearAll()
    }
}
