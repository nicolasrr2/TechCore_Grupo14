package com.tecnocore.app.data.repository

import com.tecnocore.app.data.dao.CartDao
import com.tecnocore.app.data.entities.CartItem
import kotlinx.coroutines.flow.Flow

class CartRepository(private val cartDao: CartDao) {

    suspend fun addToCart(item: CartItem): Long = cartDao.insert(item)

    suspend fun update(item: CartItem) = cartDao.update(item)

    suspend fun remove(item: CartItem) = cartDao.delete(item)

    fun getCartFlow(): Flow<List<CartItem>> = cartDao.getAllFlow()

    suspend fun clearCart() = cartDao.clearAll()
}
