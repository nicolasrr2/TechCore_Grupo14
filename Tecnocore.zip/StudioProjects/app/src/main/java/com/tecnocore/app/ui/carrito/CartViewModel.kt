package com.tecnocore.app.ui.carrito

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tecnocore.app.data.database.AppDatabase
import com.tecnocore.app.data.entities.CartItem
import com.tecnocore.app.data.repository.CartRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CartViewModel(application: Application) : AndroidViewModel(application) {

    private val cartRepository: CartRepository

    val cartItems: StateFlow<List<CartItem>>

    init {
        val cartDao = AppDatabase.getInstance(application).cartDao()
        cartRepository = CartRepository(cartDao)
        cartItems = cartRepository.getCartFlow().stateIn(
            scope = viewModelScope,
            started = SharingStarted.Lazily,
            initialValue = emptyList()
        )
    }

    fun removeItem(item: CartItem) {
        viewModelScope.launch {
            cartRepository.removeItem(item)
        }
    }

    fun updateItemQuantity(item: CartItem, newQuantity: Int) {
        viewModelScope.launch {
            cartRepository.updateItemQuantity(item, newQuantity)
        }
    }

    fun checkout() {
        viewModelScope.launch {
            cartRepository.clearCart()
        }
    }
}
