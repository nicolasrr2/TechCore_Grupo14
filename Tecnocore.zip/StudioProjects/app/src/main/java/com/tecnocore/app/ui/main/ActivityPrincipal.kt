package com.tecnocore.app.ui.main

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.widget.ImageView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.tecnocore.app.R
import com.tecnocore.app.data.ActivityDetalle
import com.tecnocore.app.data.entities.Producto
import com.tecnocore.app.databinding.ActivityPrincipalBinding
import com.tecnocore.app.ui.carrito.ActivityCarrito
import com.tecnocore.app.utils.NativeUtils

class ActivityPrincipal : AppCompatActivity() {

    private lateinit var binding: ActivityPrincipalBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var productoAdapter: ProductoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPrincipalBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        setupRecyclerView()
        setupEventListeners()
    }

    private fun setupRecyclerView() {
        productoAdapter = ProductoAdapter(
            onProductoClicked = { producto ->
                val intent = Intent(this, ActivityDetalle::class.java).apply {
                    putExtra("PRODUCT_ID", producto.id)
                }
                startActivity(intent)
            },
            onAddToCartClicked = { producto, productoImageView ->
                viewModel.addProductToCart(producto)
                Snackbar.make(binding.root, "${producto.title} añadido al carrito", Snackbar.LENGTH_SHORT).show()
                NativeUtils.vibrateShort(this)
                animateFlyToCart(productoImageView)
            }
        )

        binding.recyclerProductos.layoutManager = LinearLayoutManager(this)
        binding.recyclerProductos.adapter = productoAdapter
        productoAdapter.submitList(viewModel.productos)
    }

    private fun setupEventListeners() {
        binding.fabOpenCart.setOnClickListener {
            startActivity(Intent(this, ActivityCarrito::class.java))
        }
    }

    private fun animateFlyToCart(productoImageView: ImageView) {
        val destView = binding.fabOpenCart
        val cartIconLocation = IntArray(2)
        destView.getLocationOnScreen(cartIconLocation)

        val flyingImageView = ImageView(this)
        flyingImageView.setImageDrawable(productoImageView.drawable)
        flyingImageView.layoutParams = productoImageView.layoutParams
        flyingImageView.x = productoImageView.x
        flyingImageView.y = productoImageView.y
        addContentView(flyingImageView, flyingImageView.layoutParams)

        flyingImageView.animate()
            .x(cartIconLocation[0].toFloat())
            .y(cartIconLocation[1].toFloat())
            .setInterpolator(AccelerateInterpolator())
            .setDuration(1000)
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    flyingImageView.visibility = View.GONE
                    (flyingImageView.parent as? View)?.let {
                        it.post { (it as? android.view.ViewGroup)?.removeView(flyingImageView) }
                    }
                }
            })
            .start()
    }
}
