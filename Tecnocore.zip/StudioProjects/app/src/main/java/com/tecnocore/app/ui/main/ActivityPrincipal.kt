package com.tecnocore.app.ui.main

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.tecnocore.app.data.ActivityDetalle
import com.tecnocore.app.databinding.ActivityPrincipalBinding
import com.tecnocore.app.ui.carrito.ActivityCarrito
import com.tecnocore.app.utils.NativeUtils
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ActivityPrincipal : AppCompatActivity() {

    private lateinit var binding: ActivityPrincipalBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var productoAdapter: ProductoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPrincipalBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupEventListeners()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        productoAdapter = ProductoAdapter(
            onProductoClicked = { producto ->
                val intent = Intent(this, ActivityDetalle::class.java).apply {
                    putExtra("product_id", producto.id)
                    putExtra("product_title", producto.title)
                    putExtra("product_price", producto.price)
                    putExtra("product_description", producto.description)
                }
                startActivity(intent)
            },
            onAddToCartClicked = { producto ->
                viewModel.addProductToCart(producto)
                // Feedback para el usuario
                Snackbar.make(binding.root, "${producto.title} añadido al carrito", Snackbar.LENGTH_SHORT).show()
                // Recurso nativo: vibración (IL 2.4.1)
                NativeUtils.vibrateShort(this)
            }
        )

        binding.recyclerProductos.layoutManager = LinearLayoutManager(this)
        binding.recyclerProductos.adapter = productoAdapter
        // Entregar la lista de productos estáticos al adapter
        productoAdapter.submitList(viewModel.productos)
    }

    private fun setupEventListeners() {
        binding.btnOpenCart.setOnClickListener {
            startActivity(Intent(this, ActivityCarrito::class.java))
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.cartFlow.collectLatest { cartItems ->
                // Opcional: actualizar un contador de ítems en el carrito en la UI
                val itemCount = cartItems.sumOf { it.quantity }
                // binding.tvCartItemCount.text = itemCount.toString() // (si tuvieras un TextView para esto)
            }
        }
    }
}
