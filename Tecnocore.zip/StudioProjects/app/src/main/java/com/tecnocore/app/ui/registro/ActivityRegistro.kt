package com.tecnocore.app.ui.registro

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.tecnocore.app.data.UsuarioViewModel
import com.tecnocore.app.databinding.ActivityRegistroBinding

class ActivityRegistro : AppCompatActivity() {

    private lateinit var binding: ActivityRegistroBinding
    private val usuarioViewModel: UsuarioViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRegister.setOnClickListener {
            val nombre = binding.etName.text.toString()
            val email = binding.etEmail.text.toString()
            val pass = binding.etPassword.text.toString()
            binding.progressBar.visibility = View.VISIBLE
            usuarioViewModel.registrarUsuario(nombre, email, pass) { success, msg ->
                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    if (success) {
                        Toast.makeText(this, "Registrado con éxito", Toast.LENGTH_SHORT).show()
                        finish()
                    } else {
                        if (msg?.contains("Email") == true) binding.tilEmail.error = msg
                        else if (msg?.contains("Nombre") == true) binding.tilName.error = msg
                        else if (msg?.contains("Contraseña") == true) binding.tilPassword.error = msg
                        Toast.makeText(this, msg ?: "Error de registro", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}
