package com.tecnocore.app.ui.registro

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import com.tecnocore.app.R
import com.tecnocore.app.databinding.ActivityRegistroBinding

class ActivityRegistro : AppCompatActivity() {

    private lateinit var binding: ActivityRegistroBinding
    private val viewModel: RegistroViewModel by viewModels()

    private val requestCameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            openCamera()
        } else {
            Toast.makeText(this, "Permiso de cámara denegado", Toast.LENGTH_SHORT).show()
        }
    }

    private val openCameraLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            Toast.makeText(this, "Foto capturada (simulado)", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRegionDropdown()
        setupEventListeners()
        observeViewModel()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }

    private fun setupRegionDropdown() {
        val regiones = resources.getStringArray(R.array.regiones_chile)
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, regiones)
        binding.actvRegion.setAdapter(adapter)
    }

    private fun setupEventListeners() {
        binding.ivProfileImage.setOnClickListener {
            checkCameraPermissionAndOpenCamera()
        }

        binding.btnRegister.setOnClickListener {
            viewModel.registrarUsuario(
                binding.etName.text.toString(),
                binding.etEmail.text.toString(),
                binding.etPassword.text.toString(),
                binding.etConfirmPassword.text.toString(),
                binding.actvRegion.text.toString()
            )
        }

        binding.tvGoLogin.setOnClickListener {
            finish()
        }

        binding.etName.doAfterTextChanged { viewModel.validateNombre(it.toString()) }
        binding.etEmail.doAfterTextChanged { viewModel.validateEmail(it.toString()) }
        binding.etPassword.doAfterTextChanged { viewModel.validatePassword(it.toString()) }
        binding.etConfirmPassword.doAfterTextChanged {
             viewModel.validateConfirmPassword(binding.etPassword.text.toString(), it.toString())
        }
        binding.actvRegion.doAfterTextChanged { viewModel.validateRegion(it.toString()) }
    }

    private fun observeViewModel() {
        viewModel.nombreError.observe(this) { error ->
            binding.tilName.error = error
            binding.tilName.isErrorEnabled = error != null
        }

        viewModel.emailError.observe(this) { error ->
            binding.tilEmail.error = error
            binding.tilEmail.isErrorEnabled = error != null
        }

        viewModel.passwordError.observe(this) { error ->
            binding.tilPassword.error = error
            binding.tilPassword.isErrorEnabled = error != null
        }

        viewModel.confirmPasswordError.observe(this) { error ->
            binding.tilConfirmPassword.error = error
            binding.tilConfirmPassword.isErrorEnabled = error != null
        }

        viewModel.regionError.observe(this) { error ->
            binding.tilRegion.error = error
            binding.tilRegion.isErrorEnabled = error != null
        }

        viewModel.registroState.observe(this) { state ->
            when (state) {
                is RegistroState.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                    binding.btnRegister.isEnabled = false
                }
                is RegistroState.Success -> {
                    binding.progressBar.visibility = View.GONE
                    binding.btnRegister.isEnabled = true
                    Toast.makeText(this, state.message, Toast.LENGTH_SHORT).show()
                    finish()
                }
                is RegistroState.Error -> {
                    binding.progressBar.visibility = View.GONE
                    binding.btnRegister.isEnabled = true
                    Toast.makeText(this, state.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun checkCameraPermissionAndOpenCamera() {
        when {
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED -> {
                openCamera()
            }
            else -> {
                requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
    }

    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        openCameraLauncher.launch(intent)
    }
}
