package com.tecnocore.app.data.repository

import com.tecnocore.app.data.dao.UsuarioDao
import com.tecnocore.app.data.entities.Usuario
import kotlinx.coroutines.flow.Flow

class UsuarioRepository(private val usuarioDao: UsuarioDao) {

    suspend fun insert(usuario: Usuario): Long = usuarioDao.insert(usuario)

    suspend fun update(usuario: Usuario) = usuarioDao.update(usuario)

    suspend fun delete(usuario: Usuario) = usuarioDao.delete(usuario)

    suspend fun getByEmail(email: String): Usuario? = usuarioDao.getByEmail(email)

    fun getAllUsuarios(): Flow<List<Usuario>> = usuarioDao.getAllFlow()
}
