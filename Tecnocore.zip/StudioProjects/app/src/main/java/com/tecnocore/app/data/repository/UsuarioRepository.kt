package com.tecnocore.app.data.repository

import com.tecnocore.app.data.dao.UsuarioDao
import com.tecnocore.app.data.entities.Usuario

class UsuarioRepository(private val usuarioDao: UsuarioDao) {

    suspend fun registrarUsuario(usuario: Usuario): Long {
        return usuarioDao.insert(usuario)
    }

    // Este es el método que faltaba y que el LoginViewModel necesita.
    suspend fun findUsuarioByEmail(email: String): Usuario? {
        return usuarioDao.findByEmail(email)
    }

}
