package com.tecnocore.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.tecnocore.app.ui.login.ActivityInicioSesion

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Aquí decides la primera pantalla
        startActivity(Intent(this, ActivityInicioSesion::class.java))
        finish()
    }
}
