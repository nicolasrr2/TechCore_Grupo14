package com.tecnocore.app.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tecnocore.app.data.database.AppDatabase
import com.tecnocore.app.data.entities.Usuario
import com.tecnocore.app.data.repository.UsuarioRepository
import kotlinx.coroutines.launch


class UsuarioViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: UsuarioRepository

    init {
        val usuarioDao = AppDatabase.getInstance(application).usuarioDao()
        repository = UsuarioRepository(usuarioDao)
    }

    fun registrarUsuario(nombre: String, email: String, password: String, callback: (Boolean, String?) -> Unit) {
        viewModelScope.launch {

            if (nombre.isBlank() || email.isBlank() || password.isBlank()) {
                callback(false, "Todos los campos son obligatorios")
                return@launch
            }
            if (password.length < 6) {
                 callback(false, "La contraseña debe tener al menos 6 caracteres")
                return@launch
            }


            val existe = repository.findUsuarioByEmail(email)
            if (existe != null) {
                callback(false, "El email ya está registrado")
                return@launch
            }

            val usuario = Usuario(nombre = nombre, email = email, password = password)

            val id = repository.registrarUsuario(usuario)
            callback(id > 0, null)
        }
    }
}
