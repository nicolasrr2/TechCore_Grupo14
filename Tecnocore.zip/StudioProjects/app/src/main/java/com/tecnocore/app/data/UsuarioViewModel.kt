package com.tecnocore.app.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tecnocore.app.data.database.AppDatabase
import com.tecnocore.app.data.entities.Usuario
import com.tecnocore.app.data.repository.UsuarioRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class UsuarioViewModel(application: Application) : AndroidViewModel(application) {

    private val usuarioDao = AppDatabase.getInstance(application).usuarioDao()
    private val repository = UsuarioRepository(usuarioDao)

    // Ejemplo: observar usuarios si es necesario
    val usuariosFlow = repository.getAllUsuarios().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun registrarUsuario(nombre: String, email: String, password: String, callback: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            // Validaciones
            if (!Validate.isNameValid(nombre)) { callback(false, "Nombre inválido"); return@launch }
            if (!Validate.isEmailValid(email)) { callback(false, "Email inválido"); return@launch }
            if (!Validate.isPasswordValid(password)) { callback(false, "Contraseña mínima 6"); return@launch }

            val existe = repository.getByEmail(email)
            if (existe != null) { callback(false, "Email ya registrado"); return@launch }

            val id = repository.insert(Usuario(nombre = nombre, email = email, password = password))
            callback(id > 0, null)
        }
    }

    fun loginUsuario(email: String, password: String, callback: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val usuario = repository.getByEmail(email)
            if (usuario == null) { callback(false, "Usuario no encontrado"); return@launch }
            if (usuario.password != password) { callback(false, "Contraseña incorrecta"); return@launch }
            callback(true, null)
        }
    }
}
