package com.tecnocore.app.ui.carrito

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.tecnocore.app.data.entities.CartItem
import com.tecnocore.app.databinding.ItemCartBinding

class CartAdapter(
    private val onRemoveClicked: (CartItem) -> Unit,
    private val onQuantityChanged: (CartItem, Int) -> Unit
) : ListAdapter<CartItem, CartAdapter.CartViewHolder>(CartDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val binding = ItemCartBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CartViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item)
    }

    inner class CartViewHolder(private val binding: ItemCartBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: CartItem) {
            binding.tvTitle.text = item.title
            binding.tvPrice.text = String.format("$%.2f", item.price)
            binding.etQuantity.setText(item.quantity.toString())

            binding.btnRemove.setOnClickListener { 
                onRemoveClicked(item)
            }

            binding.btnInc.setOnClickListener {
                val newQuantity = item.quantity + 1
                binding.etQuantity.setText(newQuantity.toString())
                onQuantityChanged(item, newQuantity)
            }

            binding.btnDec.setOnClickListener {
                if (item.quantity > 1) {
                    val newQuantity = item.quantity - 1
                    binding.etQuantity.setText(newQuantity.toString())
                    onQuantityChanged(item, newQuantity)
                }
            }
        }
    }
}

class CartDiffCallback : DiffUtil.ItemCallback<CartItem>() {
    override fun areItemsTheSame(oldItem: CartItem, newItem: CartItem): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: CartItem, newItem: CartItem): Boolean {
        return oldItem == newItem
    }
}
