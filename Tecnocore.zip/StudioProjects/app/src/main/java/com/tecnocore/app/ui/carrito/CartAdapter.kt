package com.tecnocore.app.ui.carrito

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.tecnocore.app.data.entities.CartItem
import com.tecnocore.app.databinding.ItemCartBinding

class CartAdapter(
    private var items: MutableList<CartItem>,
    private val onRemove: (CartItem) -> Unit,
    private val onQuantityChanged: (CartItem) -> Unit
) : RecyclerView.Adapter<CartAdapter.VH>() {

    inner class VH(val binding: ItemCartBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemCartBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val it = items[position]
        holder.binding.tvTitle.text = it.title
        holder.binding.tvPrice.text = String.format("$%.2f", it.price)
        holder.binding.etQuantity.setText(it.quantity.toString())

        holder.binding.btnRemove.setOnClickListener { onRemove(it) }

        holder.binding.btnInc.setOnClickListener {
            val newQ = it.quantity + 1
            val updated = it.copy(quantity = newQ)
            items[position] = updated
            onQuantityChanged(updated)
            notifyItemChanged(position)
        }
        holder.binding.btnDec.setOnClickListener {
            val newQ = if (it.quantity > 1) it.quantity - 1 else 1
            val updated = it.copy(quantity = newQ)
            items[position] = updated
            onQuantityChanged(updated)
            notifyItemChanged(position)
        }
    }

    override fun getItemCount(): Int = items.size

    fun updateItems(newItems: MutableList<CartItem>) {
        this.items = newItems
        notifyDataSetChanged()
    }
}
